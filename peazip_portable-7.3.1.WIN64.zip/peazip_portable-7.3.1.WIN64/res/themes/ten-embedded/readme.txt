TEN-EMBEDDED
Embedded themes does not contain .theme file nor graphic, that is embedded in PeaZip for maximum startup performances.
Ten theme provides icons meant to integrate the application's look and feel in a Windows 10 or more recent environment, in order to provide more familiar visual metaphors to users of those systems.