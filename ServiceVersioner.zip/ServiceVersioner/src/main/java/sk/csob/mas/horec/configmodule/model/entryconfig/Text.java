
package sk.csob.mas.horec.configmodule.model.entryconfig;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.EqualsAndHashCode;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "module",
    "version",
    "constraints"
})
@EqualsAndHashCode(exclude = {"constraints"})
public class Text implements VersionedEntry {

    @JsonProperty("module")
    private String module;
    @JsonProperty("version")
    private String version;
    @JsonProperty("constraints")
    private List<Constraint> constraints = null;

    @JsonProperty("module")
    public String getModule() {
        return module;
    }

    @JsonProperty("module")
    public void setModule(String module) {
        this.module = module;
    }

    public Text withModule(String module) {
        this.module = module;
        return this;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    @JsonProperty("version")
    public void setVersion(String version) {
        this.version = version;
    }

    public Text withVersion(String version) {
        this.version = version;
        return this;
    }

    @JsonProperty("constraints")
    public List<Constraint> getConstraints() {
        return constraints;
    }

    @JsonProperty("constraints")
    public void setConstraints(List<Constraint> constraints) {
        this.constraints = constraints;
    }

    public Text withConstraints(List<Constraint> constraints) {
        this.constraints = constraints;
        return this;
    }

}
