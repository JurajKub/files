package sk.csob.mas.horec.configmodule.util;

import java.util.ArrayList;
import java.util.List;

import sk.csob.mas.horec.configmodule.model.entryconfig.AppVersion;
import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

public class AppVersionUtil {
	
	public static Padder from(List<AppVersion> appVersionList) {
		List<Integer> versionList = new ArrayList<>();
		for(AppVersion appVersion : appVersionList) {
			if(appVersion.getFrom() != null) {
				versionList.add(getMajorVersion(appVersion.getFrom()));
			}
			
			if(appVersion.getTo() != null) {
				versionList.add(getMajorVersion(appVersion.getTo()));
			}
		}
		
		return PaddingUtil.sharedPadding(versionList, 4);
	}
	

	private static Integer getMajorVersion(String value) {
		if(value.contains(".")) {
			return Integer.valueOf(value.split("\\.")[0]);
		}
		
		return Integer.valueOf(value);
	}

	private static Integer normalizeValue(String value) {
		return Integer.valueOf(value.replaceAll(".", ""));
	}

}
