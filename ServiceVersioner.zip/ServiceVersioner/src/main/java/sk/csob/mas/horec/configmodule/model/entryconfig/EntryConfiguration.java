
package sk.csob.mas.horec.configmodule.model.entryconfig;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "default",
    "configs",
    "texts"
})
public class EntryConfiguration {

    @JsonProperty("default")
    private Default _default;
    @JsonProperty("configs")
    private List<Config> configs = null;
    @JsonProperty("texts")
    private List<Text> texts = null;

    @JsonProperty("default")
    public Default getDefault() {
        return _default;
    }

    @JsonProperty("default")
    public void setDefault(Default _default) {
        this._default = _default;
    }

    public EntryConfiguration withDefault(Default _default) {
        this._default = _default;
        return this;
    }

    @JsonProperty("configs")
    public List<Config> getConfigs() {
        return configs;
    }

    @JsonProperty("configs")
    public void setConfigs(List<Config> configs) {
        this.configs = configs;
    }

    public EntryConfiguration withConfigs(List<Config> configs) {
        this.configs = configs;
        return this;
    }

    @JsonProperty("texts")
    public List<Text> getTexts() {
        return texts;
    }

    @JsonProperty("texts")
    public void setTexts(List<Text> texts) {
        this.texts = texts;
    }

    public EntryConfiguration withTexts(List<Text> texts) {
        this.texts = texts;
        return this;
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this._default == null)? 0 :this._default.hashCode()));
        result = ((result* 31)+((this.configs == null)? 0 :this.configs.hashCode()));
        result = ((result* 31)+((this.texts == null)? 0 :this.texts.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof EntryConfiguration) == false) {
            return false;
        }
        EntryConfiguration rhs = ((EntryConfiguration) other);
        return ((((this._default == rhs._default)||((this._default!= null)&&this._default.equals(rhs._default)))&&((this.configs == rhs.configs)||((this.configs!= null)&&this.configs.equals(rhs.configs))))&&((this.texts == rhs.texts)||((this.texts!= null)&&this.texts.equals(rhs.texts))));
    }

}
