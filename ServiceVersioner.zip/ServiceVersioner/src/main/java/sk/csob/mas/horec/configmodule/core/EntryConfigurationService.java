package sk.csob.mas.horec.configmodule.core;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.jkubinyi.corp.core.constraint.AppVersionConstraint;
import com.jkubinyi.corp.core.constraint.Constraint;
import com.jkubinyi.corp.core.constraint.ValidConstraint;

import sk.csob.mas.horec.configmodule.model.cache.ConstraintGroup;
import sk.csob.mas.horec.configmodule.model.cache.EntryConfiguration;
import sk.csob.mas.horec.configmodule.model.cache.MatchedConstraintGroup;
import sk.csob.mas.horec.configmodule.model.cache.VersionedModule;
import sk.csob.mas.horec.configmodule.util.ModuleVersion;
import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

public class EntryConfigurationService {
	
	public static final String CFG_FROM_SOURCE = "{\n" + 
			"    \"default\":{\n" + 
			"        \"configs\":[\n" + 
			"            {\n" + 
			"                \"module\":\"SmartBanking\",\n" + 
			"                \"version\":\"0\"\n" + 
			"            },\n" + 
			"            {\n" + 
			"                \"module\":\"XXX\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            }\n" + 
			"        ],\n" + 
			"        \"texts\":[\n" + 
			"            {\n" + 
			"                \"module\":\"SmartBanking\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            },\n" + 
			"            {\n" + 
			"                \"module\":\"XXX\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            }\n" + 
			"        ]\n" + 
			"    },\n" + 
			"    \"configs\":[\n" + 
			"        {\n" + 
			"            \"module\":\"SmartBanking\",\n" + 
			"            \"version\":\"1\",\n" + 
			"            \"constraints\":[\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":\"1.0.1\",\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                },\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\",\n" + 
			"                        \"to\":\"2021-01-02\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                }\n" + 
			"            ]\n" + 
			"        },\n" + 
			"        {\n" + 
			"            \"module\":\"SmartBanking\",\n" + 
			"            \"version\":\"2\",\n" + 
			"            \"constraints\":[\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-04-06 00:20\",\n" + 
			"                        \"to\":\"2021-04-06 02:00\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                },\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                },\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\",\n" + 
			"                        \"to\":\"2021-01-03\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                }\n" + 
			"            ]\n" + 
			"        }\n" + 
			"    ],\n" + 
			"    \"texts\":[\n" + 
			"        {\n" + 
			"            \"module\":\"SmartBanking\",\n" + 
			"            \"version\":\"1\",\n" + 
			"            \"constraints\":[\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1\n" + 
			"                    }\n" + 
			"                }\n" + 
			"            ]\n" + 
			"        }\n" + 
			"    ]\n" + 
			"}";
	
	public VersionedModule getConfiguration(String moduleName, String appVersion) throws JsonMappingException, JsonProcessingException {
		EntryConfiguration entryConfiguration = new Parser().parseEntryConfiguration(CFG_FROM_SOURCE);
		List<VersionedModule> versionedModuleList = getByModuleName(moduleName, entryConfiguration.getConfigs());
		Map<String, Object> parametersMap = parametersMap(appVersion, entryConfiguration.getPadder());
		
		return getVersionedModuleByConstraints(versionedModuleList, parametersMap)
				.orElseGet(
						() -> getDefaultModuleVersion(moduleName, entryConfiguration)
						.orElseThrow(() -> new IllegalArgumentException("Module " + moduleName + " not found."))
				);
	}
	
	private Optional<VersionedModule> getDefaultModuleVersion(String moduleName, EntryConfiguration entryConfiguration) {
		List<VersionedModule> versionedModuleList = getByModuleName(moduleName, entryConfiguration.getDefaultConfig().getConfigList());
		if(versionedModuleList.isEmpty()) {
			return Optional.empty();
		}
		
		return Optional.of(versionedModuleList.get(0));
	}
	
	private Optional<VersionedModule> getVersionedModuleByConstraints(List<VersionedModule> versionedModuleList, Map<String, Object> parametersMap) {
		return filterConstraints(versionedModuleList, parametersMap);
	}
	
	private Map<String, Object> parametersMap(String appVersion, Padder padder) {
		Map<String, Object> parametersMap = new LinkedHashMap<>();
		parametersMap.put(AppVersionConstraint.CONSTRAINT_NAME, AppVersion.concrete(appVersion, padder).getPadded().getFrom());
		parametersMap.put(ValidConstraint.CONSTRAINT_NAME, LocalDateTime.now());
		
		return parametersMap;
	}
	
	private List<VersionedModule> getByModuleName(String moduleName, List<? extends VersionedModule> versionModuleList) {
		return versionModuleList.stream()
				.filter(module -> module.getModule().equals(moduleName))
				.collect(Collectors.toList());
	}
	
	private Optional<VersionedModule> filterConstraints(List<VersionedModule> versionedModuleList, Map<String, Object> parametersMap) {
		Map<Long, VersionedModule> versionedModuleByScore = new LinkedHashMap<>();
		for(VersionedModule versionedModule : versionedModuleList) {
			Optional<MatchedConstraintGroup> optionalMatchedConstraintGroup = matchConstraintGroup(versionedModule.getConstraintGroupList(), parametersMap);
			if(optionalMatchedConstraintGroup.isPresent()) {
				MatchedConstraintGroup matchedConstraintGroup = optionalMatchedConstraintGroup.get();
				versionedModuleByScore.put(matchedConstraintGroup.getScore(), versionedModule);
			}
		}
		
		Optional<Long> optionalBestScore = versionedModuleByScore.keySet().stream()
				.sorted(Comparator.naturalOrder())
				.findFirst();
		
		if(!optionalBestScore.isPresent()) {
			return Optional.empty();
		}
		
		return Optional.ofNullable(versionedModuleByScore.get(optionalBestScore.get()));
	}
	
	private Optional<MatchedConstraintGroup> matchConstraintGroup(List<ConstraintGroup> constraintGroupList, Map<String, Object> parametersMap) {
		boolean matches = false;
		ConstraintGroup finalConstraintGroup = null;
		long conScore = -1;
		
		for(ConstraintGroup constraintGroup : constraintGroupList) {
			boolean matchesAllConstraints = true;
			long groupScore = 0;
			for(Constraint constraint : constraintGroup.getConstraintList()) {
				long score = matchConstraint(constraint, parametersMap);
				if(score >= 0) { // -1 or lower is not matched
					groupScore = groupScore + score;
				} else {
					matchesAllConstraints = false;
				}
			}
			
			if(matchesAllConstraints) {
				if(conScore == -1 || groupScore <= conScore) {
					matches = true;
					conScore = groupScore;
					finalConstraintGroup = constraintGroup;
				}
			}
		}
		
		if(finalConstraintGroup == null) {
			return Optional.empty();
		}
		
		return Optional.of(
				MatchedConstraintGroup.builder()
				.constraintGroup(finalConstraintGroup)
				.score(conScore)
				.build());
	}
	
	private long matchConstraint(Constraint constraint, Map<String, Object> parametersMap) {
		Object val = parametersMap.get(constraint.validationName());
		return constraint.accept(val);
	}

}
