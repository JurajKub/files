package sk.csob.mas.horec.configmodule.core;

import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

public class AppVersion {
	
	private final Period<String> original;
	
	private final Period<Integer> padded;
	
	private AppVersion(String from, String to, Padder padder) {
		Integer fromInt = padder.pad(normalizeValue(from));
		Integer toInt = padder.pad(normalizeValue(to));
		this.original = Period.range(from, to);
		this.padded = Period.range(fromInt, toInt);
	}
	
	private AppVersion(String concrete, Padder padder) {
		Integer concreteInt = padder.pad(normalizeValue(concrete));
		this.original = Period.range(concrete, null);
		this.padded = Period.range(concreteInt, null);
	}
	
	public static AppVersion from(String from, String to, Padder padder) {
		return new AppVersion(from, to, padder);
	}
	
	public static AppVersion concrete(String version, Padder padder) {
		return new AppVersion(version, padder);
	}
	
	public Period<String> getOriginal() {
		return original;
	}

	public Period<Integer> getPadded() {
		return padded;
	}

	private Integer normalizeValue(String value) {
		return Integer.valueOf(value.replaceAll("\\.", ""));
	}

}
