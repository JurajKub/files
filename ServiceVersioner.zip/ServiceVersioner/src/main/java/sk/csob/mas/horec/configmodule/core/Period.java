package sk.csob.mas.horec.configmodule.core;

public class Period<T> {
	
	private final T from;
	
	private final T to;
	
	private Period(T from, T to) {
		this.from = from;
		this.to = to;
	}
	
	public static <T> Period<T> range(T from, T to) {
		return new Period<T>(from, to);
	}
	
	public static <T> Period<T> openEnded(T from) {
		return new Period<T>(from, null);
	}
	
	public T getFrom() {
		return this.from;
	}
	
	public T getTo() {
		return this.to;
	}
	
	public boolean hasFrom() {
		return this.from != null;
	}

	public boolean hasTo() {
		return this.to != null;
	}

}
