package sk.csob.mas.horec.configmodule.model.cache;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@EqualsAndHashCode
public class Default {

	private List<VersionedModule> configList;
	
	private List<VersionedModule> textList;

}
