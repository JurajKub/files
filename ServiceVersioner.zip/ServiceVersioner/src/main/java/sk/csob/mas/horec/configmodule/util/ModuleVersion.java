package sk.csob.mas.horec.configmodule.util;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Builder
@Getter
@EqualsAndHashCode
public class ModuleVersion {
	
    public String name;
    
    public String version;
    
}