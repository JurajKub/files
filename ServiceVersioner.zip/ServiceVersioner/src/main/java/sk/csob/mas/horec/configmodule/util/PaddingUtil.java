package sk.csob.mas.horec.configmodule.util;

import java.util.List;

public class PaddingUtil {
	
	/**
	 * Calculates shared minimum padding.
	 * 
	 * @param numbersList List of numbers to be padded.
	 * @param minimumPadding
	 * @return
	 */
	public static Padder sharedPadding(List<Integer> numbersList, int minimumPadding) {
		Integer maxNumber = numbersList.stream().mapToInt(v -> v).max().getAsInt();
		return new Padder(((int) Math.log10(maxNumber) + 1) + minimumPadding);
	}
	
	/**
	 * Padds number with defined number of zeroes.
	 * 
	 * @param in Number to be padded.
	 * @param fill Number of digits to be added.
	 * @return Number with padding.
	 */
	public static Integer padZero(int in, int fill) {
	    boolean negative = false;
	    int value, len = 0;

	    if(in >= 0){
	        value = in;
	    } else {
	        negative = true;
	        value = - in;
	        in = - in;
	        len ++;
	    }

	    if(value == 0){
	        len = 1;
	    } else{         
	        for(; value != 0; len ++){
	            value /= 10;
	        }
	    }

	    StringBuilder sb = new StringBuilder();

	    if(negative){
	        sb.append('-');
	    }

	    sb.append(in);

	    for(int i = fill; i > len; i--){
	        sb.append('0');
	    }

	    return Integer.valueOf(sb.toString());       
	}
	
	public static class Padder {
		
		private final int paddingOffset;
		
		private Padder(int paddingOffset) {
			this.paddingOffset = paddingOffset;
		}
		
		public Integer pad(Integer number) {
			return padZero(number, paddingOffset);
		}
	}

}
