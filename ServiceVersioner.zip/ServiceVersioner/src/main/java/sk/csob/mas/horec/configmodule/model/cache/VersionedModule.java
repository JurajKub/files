package sk.csob.mas.horec.configmodule.model.cache;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@Builder
@EqualsAndHashCode(exclude = {"constraintGroupList"})
@ToString
public class VersionedModule {
	
	private String module;
	
	private String version;
	
	private List<ConstraintGroup> constraintGroupList;

}
