package sk.csob.mas.horec.configmodule.model.cache;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@EqualsAndHashCode
public class MatchedConstraintGroup {
	
	private ConstraintGroup constraintGroup;
	
	private long score;

}
