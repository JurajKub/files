
package sk.csob.mas.horec.configmodule.model.entryconfig;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "configs",
    "texts"
})
public class Default {

    @JsonProperty("configs")
    private List<Config> configs = null;
    @JsonProperty("texts")
    private List<Text> texts = null;

    @JsonProperty("configs")
    public List<Config> getConfigs() {
        return configs;
    }

    @JsonProperty("configs")
    public void setConfigs(List<Config> configs) {
        this.configs = configs;
    }

    public Default withConfigs(List<Config> configs) {
        this.configs = configs;
        return this;
    }

    @JsonProperty("texts")
    public List<Text> getTexts() {
        return texts;
    }

    @JsonProperty("texts")
    public void setTexts(List<Text> texts) {
        this.texts = texts;
    }

    public Default withTexts(List<Text> texts) {
        this.texts = texts;
        return this;
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.texts == null)? 0 :this.texts.hashCode()));
        result = ((result* 31)+((this.configs == null)? 0 :this.configs.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Default) == false) {
            return false;
        }
        Default rhs = ((Default) other);
        return (((this.texts == rhs.texts)||((this.texts!= null)&&this.texts.equals(rhs.texts)))&&((this.configs == rhs.configs)||((this.configs!= null)&&this.configs.equals(rhs.configs))));
    }

}
