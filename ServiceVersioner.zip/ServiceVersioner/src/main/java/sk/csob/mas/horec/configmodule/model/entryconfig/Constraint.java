
package sk.csob.mas.horec.configmodule.model.entryconfig;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "valid",
    "appVersion"
})
@EqualsAndHashCode
@ToString
public class Constraint {

    @JsonProperty("valid")
    private Valid valid;
    @JsonProperty("appVersion")
    private AppVersion appVersion;

    @JsonProperty("valid")
    public Valid getValid() {
        return valid;
    }

    @JsonProperty("valid")
    public void setValid(Valid valid) {
        this.valid = valid;
    }

    public Constraint withValid(Valid valid) {
        this.valid = valid;
        return this;
    }

    @JsonProperty("appVersion")
    public AppVersion getAppVersion() {
        return appVersion;
    }

    @JsonProperty("appVersion")
    public void setAppVersion(AppVersion appVersion) {
        this.appVersion = appVersion;
    }

    public Constraint withAppVersion(AppVersion appVersion) {
        this.appVersion = appVersion;
        return this;
    }

}
