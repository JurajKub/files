package sk.csob.mas.horec.configmodule.exception;

public class InvalidConstraintException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidConstraintException(String message) {
		super(message);
	}
}
