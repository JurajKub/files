package sk.csob.mas.horec.configmodule.model.cache;

import java.util.List;

import com.jkubinyi.corp.core.constraint.Constraint;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@EqualsAndHashCode
public class ConstraintGroup {
	
	private List<Constraint> constraintList;

}
