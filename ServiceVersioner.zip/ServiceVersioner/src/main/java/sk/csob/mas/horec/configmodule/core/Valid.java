package sk.csob.mas.horec.configmodule.core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

public class Valid {
	
	private final Period<String> original;
	
	private final Period<LocalDateTime> padded;
	
	private static final DateTimeFormatter ISO_DATE_TIME_OPT = new DateTimeFormatterBuilder()
	        .appendPattern("yyyy-MM-dd")
	        .optionalStart()
	        .appendPattern(" HH:mm")
	        .optionalEnd()
	        .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
	        .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
	        .toFormatter();
	
	private Valid(String from, String to, Padder padder) {
		LocalDateTime fromDate = LocalDateTime.parse(from, ISO_DATE_TIME_OPT);
		LocalDateTime toDate = LocalDateTime.parse(to, ISO_DATE_TIME_OPT);
		this.original = Period.range(from, to);
		this.padded = Period.range(fromDate, toDate);
	}
	
	private Valid(String concrete, Padder padder) {
		LocalDateTime concreteDate = LocalDateTime.parse(concrete, ISO_DATE_TIME_OPT);
		this.original = Period.range(concrete, null);
		this.padded = Period.range(concreteDate, null);
	}
	
	public static Valid from(String from, String to, Padder padder) {
		return new Valid(from, to, padder);
	}
	
	public static Valid concrete(String version, Padder padder) {
		return new Valid(version, padder);
	}
	
	public Period<String> getOriginal() {
		return original;
	}

	public Period<LocalDateTime> getPadded() {
		return padded;
	}

}
