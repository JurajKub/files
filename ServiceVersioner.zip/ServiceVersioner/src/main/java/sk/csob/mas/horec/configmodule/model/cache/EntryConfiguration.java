package sk.csob.mas.horec.configmodule.model.cache;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

@Getter
@Setter
@Builder
@EqualsAndHashCode
public class EntryConfiguration {
	
    private Default defaultConfig;
    
    private List<VersionedModule> configs;
    
    private List<VersionedModule> texts;
    
    private Padder padder;

}
