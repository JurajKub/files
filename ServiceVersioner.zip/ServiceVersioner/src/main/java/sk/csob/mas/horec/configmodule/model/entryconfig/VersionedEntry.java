package sk.csob.mas.horec.configmodule.model.entryconfig;

import java.util.List;

public interface VersionedEntry {
	
	public String getModule();
	
	public String getVersion();
	
	public List<Constraint> getConstraints();
}
