package sk.csob.mas.horec.configmodule.core;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jkubinyi.corp.core.constraint.AppVersionConstraint;
import com.jkubinyi.corp.core.constraint.Constraint;
import com.jkubinyi.corp.core.constraint.ValidConstraint;

import sk.csob.mas.horec.configmodule.model.cache.ConstraintGroup;
import sk.csob.mas.horec.configmodule.model.cache.Default;
import sk.csob.mas.horec.configmodule.model.cache.EntryConfiguration;
import sk.csob.mas.horec.configmodule.model.cache.VersionedModule;
import sk.csob.mas.horec.configmodule.model.entryconfig.AppVersion;
import sk.csob.mas.horec.configmodule.model.entryconfig.Valid;
import sk.csob.mas.horec.configmodule.model.entryconfig.VersionedEntry;
import sk.csob.mas.horec.configmodule.util.AppVersionUtil;
import sk.csob.mas.horec.configmodule.util.PaddingUtil.Padder;

public class Parser {
	
	private ObjectMapper objectMapper = new ObjectMapper();
	
	private static final String LABEL_DEF_CFG = "default config";

	private static final String LABEL_DEF_TXT = "default text";
	
	public EntryConfiguration parseEntryConfiguration(String config) throws JsonMappingException, JsonProcessingException {
		sk.csob.mas.horec.configmodule.model.entryconfig.EntryConfiguration entryConfiguration =
				this.objectMapper.readValue(config, sk.csob.mas.horec.configmodule.model.entryconfig.EntryConfiguration.class);
		
		preParseCheck(entryConfiguration);
		
		List<AppVersion> appVersionList = Stream.concat(
				entryConfiguration.getTexts().stream()
					.flatMap(moduleVersion -> moduleVersion.getConstraints().stream()
						.map(constraint -> constraint.getAppVersion())),
				entryConfiguration.getTexts().stream()
					.flatMap(moduleVersion -> moduleVersion.getConstraints().stream()
						.map(constraint -> constraint.getAppVersion()))
				)
				.collect(Collectors.toList());
		
		Padder padder = AppVersionUtil.from(appVersionList); // Shared padder
		Default def = Default.builder()
				.configList(entryConfiguration.getDefault().getConfigs().stream()
						.map(versionedEntry -> convert(versionedEntry, padder))
						.collect(Collectors.toList()))
				.textList(entryConfiguration.getDefault().getTexts().stream()
						.map(versionedEntry -> convert(versionedEntry, padder))
						.collect(Collectors.toList()))
				.build();
		
		
		
		return EntryConfiguration.builder()
				.defaultConfig(def)
				.configs(
						entryConfiguration.getConfigs().stream()
						.map(versionedEntry -> convert(versionedEntry, padder))
						.collect(Collectors.toList())
				)
				.texts(
						entryConfiguration.getTexts().stream()
						.map(versionedEntry -> convert(versionedEntry, padder))
						.collect(Collectors.toList())
				)
				.padder(padder)
				.build();
		
	}
	
	private VersionedModule convert(VersionedEntry versionedEntry, Padder padder) {
		List<ConstraintGroup> constraintGroupList = null;
		if(versionedEntry.getConstraints() != null) {
			constraintGroupList = versionedEntry.getConstraints().stream()
			.map(constraint -> convertGroup(constraint, padder))
			.collect(Collectors.toList());
		}
		
		if(versionedEntry.getConstraints() != null) {
			assertUnique(versionedEntry.getConstraints());
		}
		
		return VersionedModule.builder()
				.module(versionedEntry.getModule())
				.version(versionedEntry.getVersion())
				.constraintGroupList(constraintGroupList)
				.build();
	}
	
	public void assertUnique(List<sk.csob.mas.horec.configmodule.model.entryconfig.Constraint> constraintList) {
		Set<sk.csob.mas.horec.configmodule.model.entryconfig.Constraint> constraintDuplicates = 
				findConstraintDuplicates(constraintList);
		
		if(!constraintDuplicates.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			sb.append("Duplicated constraints: {");
			sb.append(constraintDuplicates.stream()
					.map(constraint -> {
						StringBuilder constraintSb = new StringBuilder();
						constraintSb.append("[appVersion: ")
						.append(constraint.getAppVersion().toString())
						.append(", valid: ")
						.append(constraint.getValid().toString())
						.append("]");
						return constraintSb.toString();
					})
					.collect(Collectors.joining(", "))
			);
			sb.append("}");
			
			throw new IllegalStateException(sb.toString());
		}
	}
	
	private Set<sk.csob.mas.horec.configmodule.model.entryconfig.Constraint> findConstraintDuplicates(List<sk.csob.mas.horec.configmodule.model.entryconfig.Constraint> constraintList) {
        Set<sk.csob.mas.horec.configmodule.model.entryconfig.Constraint> items = new HashSet<>();
        return constraintList.stream()
                .filter(n -> !items.add(n))
                .collect(Collectors.toSet());

    }
	
	private ConstraintGroup convertGroup(sk.csob.mas.horec.configmodule.model.entryconfig.Constraint constraint, Padder padder) {
		return ConstraintGroup.builder()
				.constraintList(convert(constraint, padder))
				.build();
	}
	
	private List<Constraint> convert(sk.csob.mas.horec.configmodule.model.entryconfig.Constraint constraint, Padder padder) {
		List<Constraint> constraintList = new ArrayList<>();
		if(constraint.getAppVersion() != null) {
			constraintList.add(convert(constraint.getAppVersion(), padder));
		}

		if(constraint.getValid() != null) {
			constraintList.add(convert(constraint.getValid(), padder));
		}
		
		return constraintList.stream().collect(Collectors.toList());
	}
	
	private ValidConstraint convert(Valid valid, Padder padder) {
		sk.csob.mas.horec.configmodule.core.Valid validHolder = null;
		
		if(valid.getTo() == null) {
			validHolder = sk.csob.mas.horec.configmodule.core.Valid.concrete(valid.getFrom(), padder);
		} else {
			validHolder = sk.csob.mas.horec.configmodule.core.Valid.from(valid.getFrom(), valid.getTo(), padder);
		}
		
		LocalDateTime to = validHolder.getPadded().hasTo() ? validHolder.getPadded().getTo() : LocalDateTime.MAX;
		return ValidConstraint.from(validHolder.getPadded().getFrom(), to);
	}
	
	private AppVersionConstraint convert(AppVersion appVersion, Padder padder) {
		sk.csob.mas.horec.configmodule.core.AppVersion appVersionHolder = null;
		
		if(appVersion.getTo() == null) {
			appVersionHolder = sk.csob.mas.horec.configmodule.core.AppVersion.concrete(appVersion.getFrom(), padder);
		} else {
			appVersionHolder = sk.csob.mas.horec.configmodule.core.AppVersion.from(appVersion.getFrom(), appVersion.getTo(), padder);
		}
		
		int to = appVersionHolder.getPadded().hasTo() ? appVersionHolder.getPadded().getTo() : Integer.MAX_VALUE;
		return AppVersionConstraint.from(appVersionHolder.getPadded().getFrom(), to);
	}
	
	private void preParseCheck(sk.csob.mas.horec.configmodule.model.entryconfig.EntryConfiguration entryConfiguration) {
		assertNoDuplicates(entryConfiguration.getDefault().getConfigs(), LABEL_DEF_CFG);
		assertNoDuplicates(entryConfiguration.getDefault().getTexts(), LABEL_DEF_TXT);
	}
	
	private void assertNoDuplicates(List<? extends VersionedEntry> versionedEntryList, String label) {
		Set<VersionedEntry> versionDuplicates = findDuplicates(versionedEntryList);
		
		if(!versionDuplicates.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			boolean appendLine = false;
			sb.append("Duplicated ")
			.append(label)
			.append(" module and version: {");
			
			for(VersionedEntry duplicatedEntry : versionDuplicates) {
				if(appendLine) {
					sb.append(", ");
				}
				
				sb.append("[module: ")
				.append(duplicatedEntry.getModule())
				.append(", version: ")
				.append(duplicatedEntry.getVersion())
				.append("]");
				
				appendLine = true;
			}
			
			sb.append("}");
			
			throw new IllegalStateException(sb.toString());
		}
	}
	
	private Set<VersionedEntry> findDuplicates(List<? extends VersionedEntry> versionedEntryList) {
        Set<String> items = new HashSet<>();
        return versionedEntryList.stream()
                .filter(n -> !items.add(n.getModule()))
                .collect(Collectors.toSet());

    }

}
