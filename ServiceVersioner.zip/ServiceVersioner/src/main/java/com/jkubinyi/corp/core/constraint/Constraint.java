package com.jkubinyi.corp.core.constraint;

public interface Constraint {
	
	/**
	 * <p>Returns number of matching score based on constraint.</p>
	 * <p>Possible values are anywhere between 0 and MAX_INT number.</p>
	 * @param value Tested value.
	 * @return
	 */
	public long accept(Object value);
	
	/**
	 * Used to pick validator based on input.
	 * @return Unique name of the validator.
	 */
	public String validationName();

}
