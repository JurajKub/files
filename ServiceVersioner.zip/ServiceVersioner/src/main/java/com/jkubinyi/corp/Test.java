package com.jkubinyi.corp;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import sk.csob.mas.horec.configmodule.core.EntryConfigurationService;
import sk.csob.mas.horec.configmodule.model.cache.VersionedModule;

public class Test {

	public static void main(String... args) throws JsonMappingException, JsonProcessingException {
		VersionedModule versionedModule = new EntryConfigurationService().getConfiguration("SmartBanking", "1.0.1");
		
		System.out.println("Module version: ");
		System.out.print(versionedModule.getVersion());
	}

}
