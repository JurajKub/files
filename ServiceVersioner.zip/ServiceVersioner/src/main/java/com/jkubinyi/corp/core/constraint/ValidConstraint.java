package com.jkubinyi.corp.core.constraint;

import java.time.LocalDateTime;
import java.time.ZoneId;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@EqualsAndHashCode
@ToString
public class ValidConstraint implements Constraint {

	public static final String CONSTRAINT_NAME = "valid";
	
	private final LocalDateTime from;
	
	private final LocalDateTime to;
	
	private ValidConstraint(LocalDateTime from, LocalDateTime to) {
		this.from = from;
		this.to = to;
		
	}
	
	public static final ValidConstraint from(LocalDateTime from, LocalDateTime to) {
		return new ValidConstraint(from, to);
	}

	@Override
	public long accept(Object value) {
		if(!(value instanceof LocalDateTime) && value != null) {
			throw new IllegalArgumentException("Value is not type of LocalDateTime.");
		}
		
		LocalDateTime val = value != null ? (LocalDateTime) value : LocalDateTime.now();
		if(val.isBefore(from) || val.isAfter(to)) return -1;
		
		long valSeconds = val.atZone(ZoneId.systemDefault()).toEpochSecond();
		long fromSeconds = from.atZone(ZoneId.systemDefault()).toEpochSecond();
		long toSeconds = to.atZone(ZoneId.systemDefault()).toEpochSecond();
		
		return Math.abs(valSeconds - fromSeconds) + Math.abs(toSeconds - valSeconds);
	}

	@Override
	public String validationName() {
		return CONSTRAINT_NAME;
	}

}
