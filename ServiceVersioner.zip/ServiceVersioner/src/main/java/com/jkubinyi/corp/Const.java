package com.jkubinyi.corp;

public class Const {
	
	public static final String CFG_FROM_SOURCE = "{\n" + 
			"    \"default\":{\n" + 
			"        \"configs\":[\n" + 
			"            {\n" + 
			"                \"module\":\"SmartBanking\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            },\n" + 
			"            {\n" + 
			"                \"module\":\"XXX\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            }\n" + 
			"        ],\n" + 
			"        \"texts\":[\n" + 
			"            {\n" + 
			"                \"module\":\"SmartBanking\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            },\n" + 
			"            {\n" + 
			"                \"module\":\"XXX\",\n" + 
			"                \"version\":\"1\"\n" + 
			"            }\n" + 
			"        ]\n" + 
			"    },\n" + 
			"    \"configs\":[\n" + 
			"        {\n" + 
			"            \"module\":\"SmartBanking\",\n" + 
			"            \"version\":\"1\",\n" + 
			"            \"constraints\":[\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                },\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\",\n" + 
			"                        \"to\":\"2021-01-02\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1,\n" + 
			"                        \"to\":2\n" + 
			"                    }\n" + 
			"                }\n" + 
			"            ]\n" + 
			"        }\n" + 
			"    ],\n" + 
			"    \"texts\":[\n" + 
			"        {\n" + 
			"            \"module\":\"SmartBanking\",\n" + 
			"            \"version\":\"1\",\n" + 
			"            \"constraints\":[\n" + 
			"                {\n" + 
			"                    \"valid\":{\n" + 
			"                        \"from\":\"2021-01-01\"\n" + 
			"                    },\n" + 
			"                    \"appVersion\":{\n" + 
			"                        \"from\":1\n" + 
			"                    }\n" + 
			"                }\n" + 
			"            ]\n" + 
			"        }\n" + 
			"    ]\n" + 
			"}";

}
