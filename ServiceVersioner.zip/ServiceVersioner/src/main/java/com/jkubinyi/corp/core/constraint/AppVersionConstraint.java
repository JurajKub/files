package com.jkubinyi.corp.core.constraint;

import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * AppVersion constraint validator. MUST be used only on
 * padded ranges to the same length as value.
 * 
 * @author b1
 *
 */
@EqualsAndHashCode
@ToString
public class AppVersionConstraint implements Constraint {
	
	public static final String CONSTRAINT_NAME = "appVersion";
	
	private final int from;
	
	private final int to;
	
	private AppVersionConstraint(int from, int to) {
		this.from = from;
		this.to = to;
		
	}
	
	public static final AppVersionConstraint from(int from, int to) {
		return new AppVersionConstraint(from, to);
	}

	@Override
	public long accept(Object value) {
		if(!(value instanceof Integer)) {
			throw new IllegalArgumentException("Value is not type of Integer.");
		}
		
		Integer val = (Integer) value;
		if(val < from || val > to) return -1;
		
		return Math.abs(val - from) + Math.abs(to - val);
	}

	@Override
	public String validationName() {
		return CONSTRAINT_NAME;
	}

}
